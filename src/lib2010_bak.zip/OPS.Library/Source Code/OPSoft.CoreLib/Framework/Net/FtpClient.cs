﻿/*
 * Copyright 2010 OPS,All right reseved .
 * name     : ftpclient
 * author   : newmin
 * date     : 2010/12/13
 */

namespace Ops.Framework.Net
{
    using System;
    using System.IO;
    using System.Net;
    using System.Text;
    using System.Text.RegularExpressions;

    public class FtpClient
    {
        private FtpWebRequest request;
        private string ftp;

        /// <summary>
        /// 服务器
        /// </summary>
        public string Server { get; set; }

        /// <summary>
        /// FTP端口
        /// </summary>
        public int Port { get; set; }

        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 根目录
        /// </summary>
        public string RootPath { get; set; }

        /// <summary>
        /// FTP请求
        /// </summary>
        public FtpWebRequest Request
        {
            get { return request; }
        }

        public FtpClient(string server, int? port, string userName, string password, string rootPath)
        {
            this.Server = server;
            this.Port = port ?? 21;
            this.RootPath = rootPath ?? "/";
            this.UserName = userName;
            this.Password = password;
            ftp = "ftp://" + server + ":" + port + rootPath;
        }

        public FtpClient(string server, string userName, string password)
        {
            this.Server = server;
            this.Port = 21;
            this.RootPath = "/";
            this.UserName = userName;
            this.Password = password;
            ftp = "ftp://" + server + ":" + Port + RootPath;
        }

        /// <summary>
        /// 连接FTP
        /// </summary>
        /// <returns>返回是否连接成功</returns>
        public bool Connection()
        {
            try
            {
                request = WebRequest.Create(ftp) as FtpWebRequest;
                request.KeepAlive = false;
                request.Method = WebRequestMethods.Ftp.ListDirectoryDetails;
                request.Credentials = new NetworkCredential(UserName, Password);
                FtpWebResponse fr = request.GetResponse() as FtpWebResponse;
                using (StreamReader sr = new StreamReader(fr.GetResponseStream()))
                {
                    if (!String.IsNullOrEmpty(sr.ReadToEnd())) return true;
                }
                return false;
            }
            catch
            {
                throw new Exception("FTP信息不正确!请检查FTP地址，端口和用户是否正确!");
            }
        }

        /// <summary>
        /// 是否存在文件或目录
        /// </summary>
        /// <param name="folderOrFileName"></param>
        /// <returns></returns>
        public bool Exists(string folderOrFileName)
        {
            request = WebRequest.Create(ftp) as FtpWebRequest;
            request.Credentials = new NetworkCredential(UserName, Password);
            request.Method = WebRequestMethods.Ftp.ListDirectoryDetails;
            using (StreamReader rd = new StreamReader(request.GetResponse().GetResponseStream()))
            {
                /*
                dir = rd.ReadToEnd();
                System.Web.HttpContext.Current.Response.Write(dir + "<br />" + count.ToString());
                 */
                string line;
                while ((line = rd.ReadLine()) != null)
                {
                    GroupCollection gc = new Regex("[^\\s]*$").Match(line).Groups;
                    if (gc.Count != 1) return false;
                    if (gc[0].Value == folderOrFileName) return true;
                }
                return false;
            }
        }

        /// <summary>
        /// 创建文件夹
        /// </summary>
        /// <param name="floderName"></param>
        public void CreateDirectory(string floderName)
        {
            request = WebRequest.Create(ftp + floderName) as FtpWebRequest;
            request.Credentials = new NetworkCredential(UserName, Password);
            request.Method = WebRequestMethods.Ftp.MakeDirectory;
            request.GetResponse();
        }

        public void UploadFile(string filePath, Stream fileStream)
        {
            const int bufferLength = 1;
            byte[] buffer = new byte[bufferLength];
            request = WebRequest.Create(ftp + filePath) as FtpWebRequest;
            request.Method = WebRequestMethods.Ftp.UploadFile;
            request.Credentials = new NetworkCredential(UserName, Password);
            request.KeepAlive = false;
            request.UseBinary = true;
            Stream requestStream = request.GetRequestStream();
            int readBytes = 0;
            do
            {
                readBytes = fileStream.Read(buffer, 0, bufferLength);
                if (readBytes != 0)
                    requestStream.Write(buffer, 0, bufferLength);
            } while (readBytes != 0);

            requestStream.Dispose();
            fileStream.Dispose();
        }
    }
}