﻿/*
 * 由SharpDevelop创建。
 * 用户： newmin
 * 日期: 2013/11/24
 * 时间: 17:48
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */

using System;

namespace Ops.Framework
{
    /// <summary>
    /// Description of StringCreatorHandler.
    /// </summary>
    public delegate String StringCreatorHandler();
}