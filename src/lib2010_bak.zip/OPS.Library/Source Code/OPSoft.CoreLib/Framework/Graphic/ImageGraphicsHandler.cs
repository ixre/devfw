﻿using System.Drawing;

namespace Ops.Framework.Graphic
{
    /// <summary>
    /// 绘图处理
    /// </summary>
    /// <param name="img"></param>
    public delegate void ImageGraphicsHandler(Image img);
}