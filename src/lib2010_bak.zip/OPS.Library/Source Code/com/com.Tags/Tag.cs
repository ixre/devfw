//
//
//  Copyright 2011 (C) OPSoft INC,All rights reseved.
//
//  Project : tagsplugin
//  File Name : Tag.cs
//  Date : 8/27/2011
//  Author : 
//
//


namespace Ops.Plugin.Tags
{

    /// <summary>
    /// ��ǩ
    /// </summary>
    public class Tag
    {
        /// <summary>
        /// ��ʶID
        /// </summary>
        public int Indent { get; set; }

        /// <summary>
        /// ����
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// ����
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// ���ӵ�ַ
        /// </summary>
        public string LinkUri { get; set; }
    }

}
