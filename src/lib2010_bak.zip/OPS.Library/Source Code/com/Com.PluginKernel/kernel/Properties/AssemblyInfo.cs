﻿using System.Reflection;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("C#插件内核")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("www.ops.cc")]
[assembly: AssemblyProduct("Com.PluginKernel")]
[assembly: AssemblyCopyright("Copyright © OPS  2010-2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("b833a605-33e5-4520-a1fd-d94ee603c0b9")]
[assembly: AssemblyVersion("1.4.0")]
[assembly: AssemblyFileVersion("1.4.0")]