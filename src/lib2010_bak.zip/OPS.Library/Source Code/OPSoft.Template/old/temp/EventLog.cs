﻿//
// Copyright (C) 2011 OPS Inc,All right reseved.
// Name:EventLog.cs
// Author:newmin
// Create:2011/06/13
//

using System;
using System.Text;

namespace Ops.Template.temp
{
    /// <summary>
    /// 事件日志
    /// </summary>
    [Obsolete]
    internal sealed class EventLog
    {
        private static StringBuilder _csb = new StringBuilder();


        internal EventLog()
        {
        }

        public string Content
        {
            get { return _csb.ToString(); }
        }

        /// <summary>
        /// 附加日志
        /// </summary>
        /// <param name="logText"></param>
        public void Append(string logText)
        {
            _csb.Append(logText);
        }

        public void Clear()
        {
            _csb.Remove(0, _csb.Length);
        }

        public override string ToString()
        {
            return _csb.ToString();
        }
    }
}