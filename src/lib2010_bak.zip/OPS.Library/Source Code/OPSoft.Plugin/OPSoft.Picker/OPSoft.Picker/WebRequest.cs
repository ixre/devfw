﻿//
//
//  Copyright 2011 @ OPSoft Inc.all rights reseved.
//
//  Project : Untitled
//  File Name : State.cs
//  Date : 2011/8/25
//  Author : 
//
//


namespace OPSoft.Plugin.NetCrawl
{
    /// <summary>
    /// �ɼ�״̬
    /// </summary>
    /* public class WebRequest
    {
        
    }*/
}