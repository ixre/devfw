﻿/*
* Copyright(C) 2010-2012 OPSoft Inc
* 
* File Name	: PagerLinkType
* Author	: Administrator
* Create	: 2012/10/9 21:50:57
* Description	:
*
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ops.Web.UI
{
    public enum PagerStyle
    {
        /// <summary>
        /// 自定义风格
        /// </summary>
        Custom = -1,

        /// <summary>
        /// 默认
        /// </summary>
        Default = 0,
        Blue = 1
    }
}
