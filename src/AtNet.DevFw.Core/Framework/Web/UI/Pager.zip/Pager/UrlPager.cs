﻿/*
* Copyright(C) 2010-2012 OPSoft Inc
* 
* File Name	: UrlPager
* Author	: Administrator
* Create	: 2012/10/9 21:49:44
* Description	:
*
*/
namespace Ops.Web.UI
{

    using System;
    using System.Text;
    using System.Text.RegularExpressions;

    public class UrlPager : IFormattable
    {
        /// <summary>
        /// 风格包
        /// </summary>
        private static readonly String[] stylePack = new string[2];

        static UrlPager()
        {
            //默认风格
            stylePack[0] = @"
                div.pagerwrap{line-height:30px;position:relative;}
                div.pagerwrap span.disabled{padding:2px 5px;color:#888;margin:0 2px;}
                div.pagerwrap span.current{padding:2px 5px;margin:0 2px;color:black;}
                div.pagerwrap input{width:30px;line-height:15px;}
                div.pagerwrap select{height:20px;overflow:hidden;line-height:18px;background:white;}
                div.pagerwrap a{line-height:25px;padding:2px 5px;margin:0 2px;color:#666;
                                        text-decoration:none;outline:none;}
                div.pagerwrap span.pageinfo{position:absolute;right:10px;top:5px;color:#4196cf}  
            ";

            //蓝色风格
            stylePack[1] = @"
                div.pagerwrap{line-height:30px;position:relative;}
                div.pagerwrap span.disabled{padding:2px 5px;border:solid 1px #999;color:#888;margin:0 2px;}
                div.pagerwrap span.current{padding:2px 5px;margin:0 2px;border:solid 1px #4196cf;}
                div.pagerwrap input{width:30px;line-height:15px;border:solid 1px #4196cf;}
                div.pagerwrap select{color:#0066cc;border:solid 1px #4196cf;padding:1px;background:white;}
                div.pagerwrap a{line-height:25px;color:#0066cc;text-decoration:none;outline:none;
                                        padding:2px 5px;background:#f5f5f5;margin:0 2px;border:solid 1px #4196cf;}
                div.pagerwrap span.pageinfo{position:absolute;right:10px;top:5px;color:#4196cf}  
             ";
        }

        public UrlPager() { }

        public UrlPager(int currentPageIndex, int pageCount)
        {
            CurrentPageIndex = currentPageIndex;
            PageCount = pageCount;
        }

        /// <summary>
        /// 当前页面索引（从1开始）
        /// </summary>
        public int CurrentPageIndex { get; set; }

        /// <summary>
        /// 页面总数
        /// </summary>
        public int PageCount { get; set; }

        /// <summary>
        /// 链接长度,创建多少个跳页链接
        /// </summary>
        public int? LinkCount { get; set; }

        /// <summary>
        /// 记录条数
        /// </summary>
        public int RecordCount { get; set; }

        /// <summary>
        /// 分页风格
        /// </summary>
        public PagerStyle Style { get; set; }

        /// <summary>
        /// 上一页文字
        /// </summary>
        public string PreviousPageText { get; set; }

        /// <summary>
        /// 下一页文字
        /// </summary>
        public string NextPageText { get; set; }

        /// <summary>
        /// 上一栏链接文字
        /// </summary>
        public string PreviousPagerLinkText { get; set; }

        /// <summary>
        /// 下一栏链接文字
        /// </summary>
        public string NextPagerLinkText { get; set; }

        /// <summary>
        /// 选页框文本
        /// </summary>
        public string SelectPageText { get; set; }

        /// <summary>
        /// 第一页链接格式
        /// </summary>
        public string FirstPageLink { get; set; }

        /// <summary>
        /// 分页链接格式
        /// </summary>
        public string LinkFormat { get; set; }

        /// <summary>
        /// 页码文本格式
        /// </summary>
        public string PageTextFormat { get; set; }

        /// <summary>
        /// 是否允许输入页码调页
        /// </summary>
        public bool EnableInput { get; set; }

        /// <summary>
        /// 使用选页
        /// </summary>
        public bool EnableSelect { get; set; }

        /// <summary>
        /// 分页详细记录,如果为空字符则用默认,为空则不显示
        /// </summary>
        public String PagerTotal { get; set; }


        /// <summary>
        /// 输入分页链接HTML代码
        /// </summary>
        /// <param name="format">例如:?domain=ops.cc&page={0},{0}将会被解析成页码</param>
        /// <param name="formatProvider"></param>
        /// <returns></returns>
        public string ToString(string format, IFormatProvider formatProvider)
        {

            //计算上一页和下一页
            int pindex = CurrentPageIndex - 1;
            int nindex = CurrentPageIndex + 1;

            StringBuilder sb = new StringBuilder();

            //设置分页格式
            if (String.IsNullOrEmpty(LinkFormat)) this.LinkFormat = format;
            string _pageCount = (this.PageCount == 0 ? 1 : this.PageCount).ToString();

            //Div Wrap
            sb.Append("<div class=\"pagerwrap\">");

            //输出上一页
            if (pindex < 1)
            {
                sb.Append("<span class=\"disabled\">").Append(PreviousPageText)
                    .Append("</span>");
            }
            else
            {
                sb.Append("<span class=\"previous\"><a href=\"")
                    .Append(String.Format(pindex == 1 ? FirstPageLink : LinkFormat, pindex))
                    .Append("\">").Append(PreviousPageText).Append("</a></span>");
            }


            //起始页:CurrentPageIndex / 10 * 10+1
            //结束页:(CurrentPageIndex%10==0?CurrentPageIndex-1: CurrentPageIndex) / 10 * 10
            //当前页数能整除10的时候需要减去10页，否则不能选中


            //链接页码数量(默认10)
            int c = LinkCount ?? 10;
            int startPage = (CurrentPageIndex - 1) / c * c + 1;

            bool _gotoPrevious = false;     //是否上一栏分页

            for (int i = 1, j = startPage; i <= c && j <= PageCount;
                    i++, j = (CurrentPageIndex % c == 0 ? CurrentPageIndex - 1 : CurrentPageIndex) / c * c + i)
            {

                //输出页面
                if (j == CurrentPageIndex)
                {
                    _gotoPrevious = j % c == 1 && j != 1;

                    if (_gotoPrevious)
                    {
                        sb.Append("<a class=\"page\" href=\"")
                            .Append(String.Format(LinkFormat, (j - 1).ToString()))
                            .Append("\">").Append(String.IsNullOrEmpty(this.PreviousPagerLinkText) ? "..." : this.PreviousPagerLinkText).
                            Append("</a>");
                    }

                    //如果为页码为当前页
                    if (String.IsNullOrEmpty(PageTextFormat))
                    {
                        sb.Append("<span class=\"current\">").Append(j.ToString()).Append("</span>");
                    }
                    else
                    {
                        sb.Append(String.Format(PageTextFormat,
                                  String.Format("<span class=\"current\">{0}</span>", j.ToString())));
                    }


                    //如果为最后一个页码，则显示下一栏
                    if (!_gotoPrevious && j % c == 0 && j != PageCount)
                    {
                        sb.Append("<a class=\"page\" href=\"")
                            .Append(String.Format(LinkFormat, (j + 1).ToString()))
                            .Append("\">").Append(String.IsNullOrEmpty(this.NextPagerLinkText) ? "..." : this.NextPagerLinkText).
                            Append("</a>");
                    }

                }
                else
                {
                    //页码不为当前页，则输出页码
                    //如果为第一页，用第一页格式
                    if (String.IsNullOrEmpty(PageTextFormat))
                    {
                        sb.Append("<a class=\"page\" href=\"").Append(String.Format(j == 1 ? FirstPageLink : LinkFormat, j))
                            .Append("\">").Append(j.ToString()).Append("</a>");
                    }
                    else
                    {
                        sb.Append(String.Format(PageTextFormat,
                                  String.Format("<a class=\"page\" href=\"{0}\">{1}</a>",
                                  String.Format(j == 1 ? FirstPageLink : LinkFormat, j),
                                  j.ToString())));
                    }
                }
            }


            //显示输入页码框
            //if (EnableInput) sb.Append("<input type=\"text\" size=\"2\"/><a href=\"#\" class=\"go\" onclick=\"gotoPage(this)\">").Append(InputButtonText ?? "跳页").Append("</a>");



            //输出下一页链接
            if (PageCount <= CurrentPageIndex)
            {
                sb.Append("<span class=\"disabled\">").Append(NextPageText).Append("</span>");
            }
            else
            {
                sb.Append("<span class=\"next\"><a href=\"").Append(String.Format(LinkFormat, CurrentPageIndex + 1))
                    .Append("\">").Append(NextPageText).Append("</a></span>");
            }

            //显示下拉选页框
            if (EnableSelect)
            {
                //选页框
                StringBuilder selectSb=new StringBuilder();
                selectSb.Append("<select onchange=\"").Append("location.href='")
                    .Append(String.Format(this.LinkFormat, "#")).Append("'.replace('#',this.value);").Append("\">");

                if (this.PageCount == 0)
                {
                    selectSb.Append("<option value=\"1\" selected=\"selected\">1</option>");
                }
                else
                {

                    for (int i = 1; i <= this.PageCount; i++)
                    {
                        selectSb.Append("<option value=\"").Append(i.ToString());
                        if (i == this.CurrentPageIndex)
                        {
                            selectSb.Append("\" selected=\"selected");
                        }
                        selectSb.Append("\">").Append(i.ToString())
                         .Append("</option>");
                    }
                }
                selectSb.Append("</select>");

                //设置下拉框HTML格式
                if (String.IsNullOrEmpty(this.SelectPageText)) this.SelectPageText = "{0}";
                else if (this.SelectPageText.IndexOf("{0}") == -1) this.SelectPageText += "{0}";

                //将选页框添加到内容中
                sb.Append(String.Format(String.Concat("<span class=\"select\">",this.SelectPageText,"</span>"), 
                    selectSb.ToString()));
            }


            //显示信息
            if (this.PagerTotal!=null)
            {
                const string _pagerTotalFormat=@"第{0}/{1}页，共{2}条。";
                string _pagerTotal = this.PagerTotal;
                if(_pagerTotal==String.Empty){
                    _pagerTotal =_pagerTotalFormat;
                }
                sb.Append("&nbsp;<span class=\"pageinfo\">");
                sb.Append(String.Format(_pagerTotal,
                    CurrentPageIndex.ToString(),
                    _pageCount.ToString(),
                    this.RecordCount.ToString()
                    ));
                sb.Append("</span>");
            }


            //Wrap Close
            sb.Append("</div>");

            #region 过时的

            //如果使用页码输入框，则输出JS
            /*
            if (EnableInput)
            {
                sb.Append(@"<script type=""text/javascript"">");
                sb.Append(String.Format("var __p={0},__f1='{1}',__f2='{2}';", PageCount, FirstPageLink, LinkFormat));
                sb.Append(@"
                            function gotoPage(t){
                                var page=t.previousSibling.value;
                                if(!/^\d+$/.test(page))page=1;
                                else if(page>__p)page=__p;
                                location.href=(page==1?__f1:__f2).replace('{0}',page);
                            }
                            </script>");
            }*/

            #endregion

            //风格
            if (Style != PagerStyle.Custom)
            {
                sb.Append("<style type=\"text/css\">")
                    .Append(stylePack[(int)Style]).Append("</style>");
            }

            return Regex.Replace(sb.ToString(), "\\s\\s|\\r|\\t", String.Empty);
        }

        /// <summary>
        /// 返回分页Html
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return ToString(null, null);
        }


        #region 扩展
        /// <summary>
        /// 创建分页信息
        /// </summary>
        /// <param name="pageSize"></param>
        /// <param name="currentPageIndex"></param>
        /// <param name="recordCount"></param>
        /// <param name="pageCount"></param>
        /// <returns></returns>
        public static string BuildPagerInfo(string format, ref int currentPageIndex, int recordCount, int pageCount)
        {
            StringBuilder sb = new StringBuilder();
            if (currentPageIndex < 1) currentPageIndex = 1;
            if (currentPageIndex > pageCount) currentPageIndex = pageCount;
            UrlPager p = new UrlPager(currentPageIndex, pageCount);
            // p.PreviousPageText = "<<";
            // p.NextPageText = ">>";
            p.Style = PagerStyle.Custom;
            p.PreviousPageText = "&lt;&lt;上一页";
            p.NextPageText = "&gt;&gt;下一页";
            p.EnableInput = true;
            p.SelectPageText = "跳页";
            p.FirstPageLink = format;
            p.PagerTotal = String.Empty;
            p.RecordCount = recordCount;

            p.LinkFormat = format;

            return p.ToString();
        }

        /// <summary>
        /// 创建分页信息
        /// </summary>
        public static string BuildPagerInfo(string firstFormat, string format, int currentPageIndex, int recordCount, int pageCount)
        {
            StringBuilder sb = new StringBuilder();

            UrlPager p = new UrlPager(currentPageIndex, pageCount);
            p.RecordCount = recordCount;
            p.Style = PagerStyle.Default;

            p.PreviousPageText = "&lt;&lt;上一页";
            p.NextPageText = "&gt;&gt;下一页";
            p.SelectPageText = "跳页";

            p.FirstPageLink = firstFormat;
            p.LinkFormat = format;
            p.EnableInput = true;
            p.PagerTotal = String.Empty;

            return p.ToString();
        }

        /// <summary>
        /// 创建分页信息
        /// </summary>
        public static string BuildPagerInfo(string format, int currentPageIndex, int recordCount, int pageCount)
        {
            StringBuilder sb = new StringBuilder();

            UrlPager p = new UrlPager(currentPageIndex, pageCount);
            p.RecordCount = recordCount;
            p.Style = PagerStyle.Default;

            p.PreviousPageText = "&lt;&lt;上一页";
            p.NextPageText = "&gt;&gt;下一页";
            p.SelectPageText = "跳页";

            p.FirstPageLink = format;
            p.LinkFormat = format;
            p.EnableInput = true;
            p.PagerTotal = String.Empty;

            return p.ToString();
        }

        /// <summary>
        /// 创建分页信息
        /// </summary>
        public static string BuildPagerInfo(UrlPager builder, string format, int currentPageIndex, int recordCount, int pageCount)
        {
            builder.FirstPageLink = format;
            builder.LinkFormat = format;
            builder.CurrentPageIndex = currentPageIndex;
            builder.RecordCount = recordCount;
            builder.PageCount = pageCount;
            return builder.ToString();
        }



        #endregion
    }

}
